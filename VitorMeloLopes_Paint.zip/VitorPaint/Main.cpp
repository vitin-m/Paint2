#include "Managers.h"

// Execu��o principal do software referente ao 2o trabalho de CG
// Aluno: V�tor Melo Lopes
int main(int argc, char** argv) {
	run(&argc, argv);
}
